package vn.agest.selenium.model;

public class User {
}
