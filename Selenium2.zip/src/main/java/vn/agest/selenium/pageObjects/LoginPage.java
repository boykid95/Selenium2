package vn.agest.selenium.pageObjects;

public class LoginPage {
}
