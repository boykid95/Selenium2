package vn.agest.selenium.pageObjects;

public class HomePage {
}
