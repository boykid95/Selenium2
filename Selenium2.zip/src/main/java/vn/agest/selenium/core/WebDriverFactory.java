package vn.agest.selenium.core;

import org.openqa.selenium.WebDriver;

public interface WebDriverFactory {
    WebDriver createDriver();
}
