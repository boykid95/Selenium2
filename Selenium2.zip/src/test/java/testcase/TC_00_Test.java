package testcase;

import org.testng.annotations.Test;

public class TC_00_Test {
    @Test
    public void demoTest() {
        System.out.println("Test is running!");
    }
}
